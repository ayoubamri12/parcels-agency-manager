<div class="sidebar">
    <div class="menu-btn">
        <i class="ph-bold ph-caret-left"></i>
    </div>
    <div class="head">
        <div class="user-img">
            <img src="<?php echo e(asset('/assets/images/aloo-salhi-logo-new.png')); ?>" alt="" />
        </div>
        <div class="user-details">
            <p class="title">Salhi<span style="color: orange;">hub</span></p>
            <p class="name">
                User </p>
        </div>
    </div>
    <div class="nav active">
        <div class="menu">
            <p class="title">Main</p>
            <ul>
                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->type == 'admin'): ?>
                        <li class="<?php echo e(request()->routeIs('home') ? 'mainMenu' : ''); ?>">
                            <a href="<?php echo e(route('home')); ?>">
                                <i class="icon ph-bold ph-house-simple"></i>
                                <span class="text">Home</span>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
                <li class="<?php echo e(request()->is('Parcels/*') ? 'mainMenu' : ''); ?>">
                    <a href="#">
                        <i class="icon fa-solid fa-box"></i>
                        <span class="text">Parcels</span>
                        <i class="arrow ph-bold ph-caret-down"></i>
                    </a>
                    <ul class="sub-menu">
                        <li class="#">
                            <?php if(auth()->guard()->check()): ?>
                                <?php if(auth()->user()->type === 'admin'): ?>
                                    <a class="<?php echo e(request()->is('Parcels/index') ? 'sub-active' : ''); ?>"
                                        href="<?php echo e(route('parcels')); ?>">
                                        <span class="text">> All Parcels</span>
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </li>
                        <li>
                            <a class="<?php echo e(request()->is('Parcels/deliverymen/index') || request()->is('Parcels/deliverymen/*') ? 'sub-active' : ''); ?>"
                                href="<?php echo e(route('deliverymen')); ?>">
                                <span class="text">> Per deliveryman</span>
                            </a>
                        </li>
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(auth()->user()->type == 'admin'): ?>
                                <li class="#">
                                    <a class="<?php echo e(request()->is('Parcels/companies/index') || request()->is('Parcels/companies/*') ? 'sub-active' : ''); ?>"
                                        href="<?php echo e(route('companies')); ?>">
                                        <span class="text">> Per Client</span>
                                    </a>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                        <li class="#">
                            <?php if(auth()->guard()->check()): ?>
                                <?php if(auth()->user()->type === 'admin'): ?>
                                    <a class="<?php echo e(request()->is('Parcels/to_return') ? 'sub-active' : ''); ?>"
                                        href="<?php echo e(route('parcels.return')); ?>">
                                        <span class="text">>To be returnd <span
                                                class="badge badge-danger"><?php echo e($rt->count()); ?></span></span>
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </li>
                    </ul>
                </li>
 <?php if(auth()->guard()->check()): ?>
            <?php if(auth()->user()->type == 'admin'): ?>
       
                <li class="<?php echo e(request()->is('parcels/payement/*') ? 'mainMenu' : ''); ?>">
                    <a href="#">
                        <i class="fas fa-money-bill-wave"></i>
                        <span class="text">Parcels payement</span>
                        <i class="arrow ph-bold ph-caret-down"></i>
                    </a>
                    <ul class="sub-menu">
                        <li class="#">
                            <a class="<?php echo e(request()->is('parcels/payement/to_pay') ? 'sub-active' : ''); ?>" href="<?php echo e(route("parcels.notPayed")); ?>">
                                <span class="text">> Not Payed</span>
                            </a>
                        </li>
                        <li class="#">
                            <a class="<?php echo e(request()->is('parcels/payement/payed') ? 'sub-active' : ''); ?>" href="<?php echo e(route("parcels.payed")); ?>">
                                <span class="text">> Payed</span>
                            </a>
                        </li>
                    </ul>
                </li>
                 <?php endif; ?>
        <?php endif; ?>
            </ul>
        </div>
        <?php if(auth()->guard()->check()): ?>
            <?php if(auth()->user()->type == 'admin'): ?>
                <div class="menu">
                    <p class="title">Settings</p>
                    <ul>
                        <li class="<?php echo e(request()->routeIs('settings') ? 'mainMenu' : ''); ?>">
                            <a href="<?php echo e(route('settings')); ?>">
                                <i class="icon ph-bold ph-gear"></i>
                                <span class="text">Settings</span>
                            </a>
                        </li>
                        <li class="<?php echo e(request()->routeIs('insertion') ? 'mainMenu' : ''); ?>">
                            <a href="<?php echo e(route('insertion')); ?>">
                                <i class="fas fa-file-upload"></i>
                                <span class="text">Data Exporting</span>
                            </a>
                        </li>
                    </ul>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        <br>
        <div class="menu">
            <p class="title">Account</p>
            <ul>

                <?php if(auth()->guard()->guest()): ?>
                    <li class="<?php echo e(request()->routeIs('login') ? 'mainMenu' : ''); ?>">
                        <a href="<?php echo e(route('login')); ?>">
                            <i class="icon ph-bold ph-sign-in"></i>
                            <span class="text">Login</span>
                        </a>

                    </li>
                <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
                    <li>
                        <a class="<?php echo e(request()->routeIs('logout') ? 'mainMenu' : ''); ?>" href="<?php echo e(route('logout')); ?>">
                            <i class="icon ph-bold ph-sign-out"></i>
                            <span class="text">Logout</span>
                        </a>

                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>

</div>
<?php /**PATH C:\laragon\www\salhiProject\resources\views/partials/sideBar.blade.php ENDPATH**/ ?>